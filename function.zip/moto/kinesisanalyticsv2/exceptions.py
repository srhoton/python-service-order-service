"""Exceptions raised by the kinesisanalyticsv2 service."""
