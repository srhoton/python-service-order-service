"""Exceptions raised by the sagemakermetrics service."""
